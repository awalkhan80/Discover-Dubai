import { CategoryLanding, categoryMetadata } from '@/components/CategoryLanding'

export const metadata = categoryMetadata(
  'Morning Desert Safari Dubai | Sunrise Dune Tour',
  'Book a morning desert safari in Dubai for cooler temperatures, sunrise dunes, guided dune driving and optional quad bike or buggy activities.',
  '/desert-safari/morning-safari',
)

export default function Page() {
  return (
    <CategoryLanding
      title="Morning Desert Safari Dubai"
      description="Start your day with a morning desert safari in Dubai, combining quiet golden dunes, guided 4x4 driving and optional adventure activities before the afternoon heat."
      eyebrow="Sunrise dunes and cooler desert air"
      intro="A morning desert safari is ideal for travelers who want to see Dubai's desert early and keep the rest of the day free. Enjoy a comfortable pickup, wide-open dune views and time for optional quad biking or dune buggy adventures."
      highlights={[
        'Early hotel pickup and a scenic drive into the Dubai desert',
        'Golden-hour dunes and guided desert driving away from the midday heat',
        'Optional quad bike and dune buggy activities for adventure seekers',
        'A flexible half-day experience for families, couples and short stays',
      ]}
      links={[
        { label: 'All Dubai Desert Safaris', href: '/desert-safari' },
        { label: 'Evening Desert Safari', href: '/desert-safari/evening-safari' },
        { label: 'Quad Bike Dubai', href: '/quad-bike-dubai' },
        { label: 'Dune Buggy Dubai', href: '/dune-buggy-dubai' },
        { label: 'Pickup guide', href: '/guides/dubai-desert-safari-pickup-guide' },
      ]}
      faqs={[
        { question: 'What time does a morning desert safari start?', answer: 'Pickup usually takes place early in the morning. The exact time depends on your hotel, season and selected package, and is confirmed when you check availability.' },
        { question: 'Is a morning safari suitable for families?', answer: 'Yes. The morning schedule is a good option for families who prefer cooler temperatures and a shorter desert experience. Ask about age requirements for optional activities.' },
        { question: 'Can I add a quad bike or dune buggy ride?', answer: 'Adventure add-ons may be available depending on the package. Choose the activity when booking or contact Discover Dubai on WhatsApp to check availability.' },
        { question: 'What should I wear for a morning desert safari?', answer: 'Wear light, comfortable clothing with closed shoes, sunglasses and sun protection. Bring a light layer during cooler months.' },
        { question: 'How long does the morning desert safari take?', answer: 'Most morning packages take several hours including pickup and return. Confirm the exact duration and inclusions for your selected experience before booking.' },
      ]}
    />
  )
}
