'use server'

import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { headers } from 'next/headers'
import { revalidatePath } from 'next/cache'
import { sql } from 'drizzle-orm'
import { existingPageCatalog } from '@/lib/cms-pages'

async function getUser() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error('Unauthorized')
  return session.user
}

export async function listCmsPages() {
  await getUser()
  const result = await db.execute(sql`SELECT id, slug, title, status, template, updated_at, published_at FROM cms_pages ORDER BY updated_at DESC`)
  return result.rows
}

export async function createCmsPage(input: { title: string; slug: string; template: string }) {
  const user = await getUser()
  const id = crypto.randomUUID()
  const versionId = crypto.randomUUID()
  await db.execute(sql`INSERT INTO cms_pages (id, slug, title, template, author_id, current_version_id) VALUES (${id}, ${input.slug}, ${input.title}, ${input.template}, ${user.id}, ${versionId})`)
  await db.execute(sql`INSERT INTO cms_page_versions (id, page_id, version_number, content, seo, created_by) VALUES (${versionId}, ${id}, 1, ${JSON.stringify({ blocks: [] })}::jsonb, ${JSON.stringify({ title: input.title, description: '' })}::jsonb, ${user.id})`)
  revalidatePath('/dashboard/pages')
  return id
}

export async function updateCmsPage(input: { id: string; title: string; slug: string; content: unknown; seo: unknown }) {
  const user = await getUser()
  const versionId = crypto.randomUUID()
  const next = await db.execute(sql`SELECT COALESCE(MAX(version_number), 0) + 1 AS version FROM cms_page_versions WHERE page_id = ${input.id}`)
  const version = Number(next.rows[0]?.version ?? 1)
  await db.execute(sql`INSERT INTO cms_page_versions (id, page_id, version_number, content, seo, created_by) VALUES (${versionId}, ${input.id}, ${version}, ${JSON.stringify(input.content)}::jsonb, ${JSON.stringify(input.seo)}::jsonb, ${user.id})`)
  await db.execute(sql`UPDATE cms_pages SET title = ${input.title}, slug = ${input.slug}, current_version_id = ${versionId}, status = 'draft', updated_at = now() WHERE id = ${input.id}`)
  revalidatePath('/dashboard/pages')
  revalidatePath(`/${input.slug}`)
}

export async function publishCmsPage(id: string) {
  const user = await getUser()
  await db.execute(sql`UPDATE cms_pages SET published_version_id = current_version_id, status = 'published', published_at = now(), updated_at = now() WHERE id = ${id} AND author_id = ${user.id}`)
  revalidatePath('/dashboard/pages')
}

export async function restoreCmsVersion(pageId: string, versionId: string) {
  const user = await getUser()
  await db.execute(sql`UPDATE cms_pages SET current_version_id = ${versionId}, status = 'draft', updated_at = now() WHERE id = ${pageId} AND author_id = ${user.id}`)
  revalidatePath('/dashboard/pages')
}

export async function getCmsPage(id: string) {
  await getUser()
  const result = await db.execute(sql`SELECT p.*, v.content, v.seo, v.version_number FROM cms_pages p LEFT JOIN cms_page_versions v ON v.id = p.current_version_id WHERE p.id = ${id}`)
  return result.rows[0] ?? null
}

export async function importExistingPages() {
  const user = await getUser()
  for (const page of existingPageCatalog) {
    const existing = await db.execute(sql`SELECT id FROM cms_pages WHERE slug = ${page.slug} LIMIT 1`)
    if (existing.rows[0]) continue
    const id = crypto.randomUUID()
    const versionId = crypto.randomUUID()
    const content = { blocks: [{ type: 'rich_text', body: page.description }] }
    const seo = { title: page.title, description: page.description }
    await db.execute(sql`INSERT INTO cms_pages (id, slug, title, template, author_id, current_version_id) VALUES (${id}, ${page.slug}, ${page.title}, ${page.template ?? 'landing'}, ${user.id}, ${versionId})`)
    await db.execute(sql`INSERT INTO cms_page_versions (id, page_id, version_number, content, seo, created_by, change_summary) VALUES (${versionId}, ${id}, 1, ${JSON.stringify(content)}::jsonb, ${JSON.stringify(seo)}::jsonb, ${user.id}, 'Imported from existing public route')`)
  }
  revalidatePath('/dashboard/pages')
}

export async function deleteCmsPage(id: string) {
  const user = await getUser()
  const page = await db.execute(sql`SELECT slug, status FROM cms_pages WHERE id = ${id} AND author_id = ${user.id} LIMIT 1`)
  const record = page.rows[0] as { slug: string; status: string } | undefined
  if (!record) throw new Error('Page not found')
  if (record.status === 'published') throw new Error('Published pages must be archived')
  await db.execute(sql`DELETE FROM cms_page_versions WHERE page_id = ${id}`)
  await db.execute(sql`DELETE FROM cms_pages WHERE id = ${id} AND author_id = ${user.id} AND status <> 'published'`)
  revalidatePath('/dashboard/pages')
}

export async function archiveCmsPage(id: string) {
  const user = await getUser()
  const page = await db.execute(sql`SELECT slug FROM cms_pages WHERE id = ${id} AND author_id = ${user.id} LIMIT 1`)
  const slug = (page.rows[0] as { slug?: string } | undefined)?.slug
  if (!slug) throw new Error('Page not found')
  await db.execute(sql`INSERT INTO cms_redirects (id, source_path, destination_path, status_code, created_by) VALUES (${crypto.randomUUID()}, ${`/${slug}`}, '/', 301, ${user.id}) ON CONFLICT (source_path) DO UPDATE SET destination_path = '/', status_code = 301`)
  await db.execute(sql`UPDATE cms_pages SET status = 'archived', updated_at = now() WHERE id = ${id} AND author_id = ${user.id}`)
  revalidatePath('/dashboard/pages')
}

export async function getCmsVersions(pageId: string) {
  await getUser()
  const result = await db.execute(sql`SELECT id, version_number, change_summary, created_at FROM cms_page_versions WHERE page_id = ${pageId} ORDER BY version_number DESC`)
  return result.rows
}
