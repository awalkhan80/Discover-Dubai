'use client'

import { FormEvent, useState } from 'react'
import { useRouter } from 'next/navigation'
import { authClient } from '@/lib/auth-client'

export default function SignInPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setPending(true)
    try {
      const result = await authClient.signIn.email({ email, password })
      if (result.error) {
        setError('Unable to sign in with those details.')
        return
      }
      router.replace('/dashboard')
      router.refresh()
    } catch (error) {
      console.error('[v0] Sign-in request failed:', error)
      setError('Unable to sign in right now. Please try again.')
    } finally {
      setPending(false)
    }
  }

  return (
    <main className="min-h-screen bg-background px-5 py-10 text-foreground sm:px-8">
      <div className="mx-auto flex min-h-[calc(100vh-5rem)] max-w-6xl items-center justify-center">
        <section className="grid w-full overflow-hidden rounded-[2rem] border border-border bg-card shadow-2xl lg:grid-cols-[1fr_0.8fr]">
          <div className="relative min-h-[280px] overflow-hidden bg-primary p-8 text-primary-foreground sm:p-12 lg:min-h-[620px]">
            <img src="https://images.pexels.com/photos/12379495/pexels-photo-12379495.jpeg?auto=compress&cs=tinysrgb&w=1400" alt="Desert safari vehicles at sunset" className="absolute inset-0 size-full object-cover opacity-45" />
            <div className="absolute inset-0 bg-primary/65" />
            <div className="relative flex h-full flex-col justify-between gap-12">
              <a href="/" aria-label="Discover Dubai home"><img src="/discover-dubai-logo.png" alt="Discover Dubai" className="h-12 w-auto object-contain" /></a>
              <div>
                <p className="mb-4 font-mono text-xs uppercase tracking-[0.25em] text-primary-foreground/70">Private operations</p>
                <h1 className="max-w-md font-serif text-5xl leading-[0.95] sm:text-6xl">Run every journey with clarity.</h1>
                <p className="mt-6 max-w-sm text-sm leading-6 text-primary-foreground/75">The operations console for tours, guest bookings, drivers and guides.</p>
              </div>
            </div>
          </div>
          <div className="flex items-center p-8 sm:p-12">
            <form onSubmit={submit} className="w-full max-w-md">
              <p className="font-mono text-xs uppercase tracking-[0.22em] text-muted-foreground">Admin access</p>
              <h2 className="mt-3 font-serif text-4xl">Welcome back.</h2>
              <p className="mt-3 text-sm leading-6 text-muted-foreground">Sign in to manage tours and booking assignments.</p>
              <div className="mt-8 flex flex-col gap-5">
                <label className="flex flex-col gap-2 text-sm font-medium">Email<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} className="h-12 rounded-xl border border-input bg-background px-4 outline-none ring-offset-background focus:ring-2 focus:ring-ring" /></label>
                <label className="flex flex-col gap-2 text-sm font-medium">Password<input required type="password" value={password} onChange={(event) => setPassword(event.target.value)} className="h-12 rounded-xl border border-input bg-background px-4 outline-none ring-offset-background focus:ring-2 focus:ring-ring" /></label>
              </div>
              {error ? <p role="alert" className="mt-4 text-sm text-destructive">{error}</p> : null}
              <button disabled={pending} className="mt-7 h-12 w-full rounded-xl bg-primary px-5 text-sm font-semibold text-primary-foreground transition hover:opacity-90 disabled:opacity-50">{pending ? 'Signing in…' : 'Sign in to dashboard'}</button>
              <a href="/" className="mt-5 block text-center text-sm text-muted-foreground hover:text-foreground">Return to website</a>
            </form>
          </div>
        </section>
      </div>
    </main>
  )
}
