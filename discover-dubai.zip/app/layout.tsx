import { Analytics } from '@vercel/analytics/next'
import { DM_Serif_Display, Geist, Geist_Mono } from 'next/font/google'
import type { Metadata, Viewport } from 'next'
import './globals.css'
import { businessDescription, businessName, businessSchema, siteUrl, jsonLd } from '@/lib/seo'
import { WhatsAppWidget } from '@/components/WhatsAppWidget'
import Script from 'next/script'

const geist = Geist({ subsets: ['latin'], variable: '--font-geist' })
const geistMono = Geist_Mono({ subsets: ['latin'], variable: '--font-geist-mono' })
const dmSerif = DM_Serif_Display({ subsets: ['latin'], weight: '400', variable: '--font-dm-serif' })

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'Discover Dubai | Dubai Desert Safari & City Tours',
    template: '%s | Discover Dubai',
  },
  description: businessDescription,
  keywords: ['Dubai Desert Safari', 'Desert Safari Dubai', 'Dubai City Tour', 'Abu Dhabi City Tour', 'Quad Bike Dubai', 'Buggy Dubai tours'],
  alternates: { canonical: siteUrl },
  openGraph: {
    type: 'website',
    url: siteUrl,
    siteName: 'Discover Dubai',
    title: 'Discover | Dubai Desert Safari & City Tours',
    description: 'Local Dubai tours, desert safaris and UAE experiences with easy pickup and personal support.',
  },
  robots: { index: true, follow: true },
  verification: { google: '0BNaN7rGAPysWjyqDkGCpHLDrwR45sxXrbbIpR8irFg' },
  generator: 'v0.app',
  icons: {
    icon: '/discover-dubai-logo.png',
    apple: '/discover-dubai-logo.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#003b55' },
  ],
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-white">
      <body className={`${geist.variable} ${geistMono.variable} ${dmSerif.variable} antialiased`}>
        {children}
        <WhatsAppWidget />
        {jsonLd(businessSchema)}
        <Script src="https://www.googletagmanager.com/gtag/js?id=G-E4CY4Z3CG3" strategy="afterInteractive" />
        <Script id="google-analytics" strategy="afterInteractive">
          {`window.dataLayer = window.dataLayer || []; function gtag(){window.dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-E4CY4Z3CG3');`}
        </Script>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
