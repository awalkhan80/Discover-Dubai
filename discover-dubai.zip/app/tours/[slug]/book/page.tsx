import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import BookingForm from '@/components/BookingForm'
import { getPersistedTour } from '@/lib/tours-db'

export const dynamic = 'force-dynamic'

export default async function TourBookingPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const tour = await getPersistedTour(slug)
  if (!tour) notFound()

  return <main className="min-h-screen bg-background text-foreground"><header className="border-b border-slate-400 bg-slate-500 text-white"><div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 lg:px-10"><Link href="/" className="flex items-center gap-3"><img src="/discover-dubai-logo.png" alt="Discover Dubai" className="h-11 w-auto object-contain" /></Link><Link href={`/tours/${tour.slug}`} className="text-sm font-bold text-white/90 hover:text-white">Back to tour details</Link></div></header><section className="mx-auto max-w-3xl px-5 pb-16 pt-8 lg:px-10"><Link href={`/tours/${tour.slug}`} className="inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground"><ArrowLeft size={16} /> Tour details</Link><div className="mt-8"><p className="text-xs font-bold uppercase tracking-[0.18em] text-primary">Secure your experience</p><h1 className="mt-2 font-serif text-4xl leading-tight md:text-5xl">Book {tour.title}</h1><p className="mt-3 text-sm leading-6 text-muted-foreground">Choose your date, options and guest details below.</p><div className="mt-8"><BookingForm tour={tour} /></div></div></section></main>
}
