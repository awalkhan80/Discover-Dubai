import Link from 'next/link'
import { PublicPageShell, PageContainer } from '@/components/PublicPageShell'
import { getPersistedTours } from '@/lib/tours-db'

export const dynamic = 'force-dynamic'

const places = [{ name: 'Dubai desert', copy: 'Red dunes, sunset camps and open-sky adventures.', slugs: ['desert-safari', 'premium-desert-safari', 'quad-bike'] }, { name: 'Dubai city', copy: 'A city of old souks, skyline icons and waterfront stories.', slugs: ['dubai-city-tour'] }, { name: 'Abu Dhabi', copy: 'Grand architecture, peaceful promenades and culture.', slugs: ['abu-dhabi-city-tour'] }]

export default async function DestinationsPage() { const tours = await getPersistedTours(); return <PublicPageShell eyebrow="Where we wander" title="Three ways into the UAE." intro="Every destination has a different rhythm. Pick a place, then let us shape a day around how you like to travel."><PageContainer><div className="grid gap-6 md:grid-cols-3">{places.map((place) => <article key={place.name} className="rounded-2xl border border-border bg-card p-7"><p className="eyebrow">{place.slugs.length} experiences</p><h2 className="mt-3 font-serif text-4xl">{place.name}</h2><p className="mt-3 text-sm leading-6 text-muted-foreground">{place.copy}</p><div className="mt-7 flex flex-col gap-3">{place.slugs.map((slug) => { const tour = tours.find((item) => item.slug === slug); return tour ? <Link key={slug} href={`/tours/${slug}`} className="flex items-center justify-between border-b border-border pb-3 text-sm font-semibold hover:text-primary"><span>{tour.title}</span><span className="text-primary">AED {tour.price}</span></Link> : null })}</div></article>)}</div></PageContainer></PublicPageShell> }
