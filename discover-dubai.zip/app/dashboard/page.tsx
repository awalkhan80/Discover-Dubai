import { redirect } from 'next/navigation'
import { headers } from 'next/headers'
import DashboardPageClient from '@/components/DashboardPageClient'
import { auth } from '@/lib/auth'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

export default async function DashboardPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect('/sign-in')
  return <DashboardPageClient userName={session.user.name} />
}
