import { redirect } from 'next/navigation'
import { headers } from 'next/headers'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { sql } from 'drizzle-orm'
import PagesCms from '@/components/PagesCms'

export const dynamic = 'force-dynamic'

export default async function PagesCmsPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect('/sign-in')
  const pages = await db.execute(sql`SELECT p.id, p.title, p.slug, p.status, p.template, p.updated_at, COALESCE(v.seo->>'description', '') AS description FROM cms_pages p LEFT JOIN cms_page_versions v ON v.id = p.current_version_id WHERE p.status <> 'archived' ORDER BY p.updated_at DESC`)
  return <main className="min-h-screen bg-muted/30 px-4 py-8 md:px-8"><div className="mx-auto max-w-7xl"><div className="mb-8"><p className="text-sm font-medium uppercase tracking-[0.2em] text-primary">Discover Dubai</p><h1 className="mt-2 text-3xl font-semibold tracking-tight">Pages CMS</h1><p className="mt-2 max-w-2xl text-muted-foreground">Draft, optimize, preview, publish, and restore the indexable pages that power the public site.</p></div><PagesCms initialPages={pages.rows as { id: string; title: string; slug: string; status: string; template: string; updated_at: string; description: string }[]} /></div></main>
}
