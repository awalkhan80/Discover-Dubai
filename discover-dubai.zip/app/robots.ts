import type { MetadataRoute } from 'next'

export default function robots(): MetadataRoute.Robots { return { rules: { userAgent: '*', allow: '/', disallow: ['/dashboard', '/api/'] }, sitemap: 'https://discover-dubai.com/sitemap.xml', host: 'https://discover-dubai.com' } }
