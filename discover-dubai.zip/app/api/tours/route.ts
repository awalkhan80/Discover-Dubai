import { NextResponse } from 'next/server'
import { headers } from 'next/headers'
import { auth } from '@/lib/auth'
import { pool } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  const result = await pool.query('SELECT id, slug, title, category, price, duration, location, image, source_url AS "sourceUrl", short_description AS "shortDescription", summary, includes, pickup_window AS "pickupWindow", transfer_included AS "transferIncluded", active FROM tours WHERE active = true ORDER BY created_at DESC')
  return NextResponse.json(result.rows)
}

export async function POST(request: Request) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const body = await request.json()
  const required = ['slug', 'title', 'category', 'price', 'duration', 'location', 'image', 'shortDescription', 'summary', 'pickupWindow']
  if (required.some((key) => !body[key])) return NextResponse.json({ error: 'Complete all required tour fields.' }, { status: 400 })
  const id = crypto.randomUUID()
  const result = await pool.query('INSERT INTO tours (id, slug, title, category, price, duration, location, image, source_url, short_description, summary, includes, pickup_window, transfer_included) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12::jsonb,$13,$14) RETURNING id, slug, title, category, price, duration, location, image, source_url AS "sourceUrl", short_description AS "shortDescription", summary, includes, pickup_window AS "pickupWindow", transfer_included AS "transferIncluded", active', [id, body.slug, body.title, body.category, Number(body.price), body.duration, body.location, body.image, body.sourceUrl ?? null, body.shortDescription, body.summary, JSON.stringify(body.includes ?? []), body.pickupWindow, Boolean(body.transferIncluded)])
  return NextResponse.json(result.rows[0], { status: 201 })
}
