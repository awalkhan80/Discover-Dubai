import { NextResponse } from 'next/server'
import { headers } from 'next/headers'
import { auth } from '@/lib/auth'
import { pool } from '@/lib/db'

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await params
  const body = await request.json()
  const result = await pool.query('UPDATE tours SET title=$1, category=$2, price=$3, duration=$4, location=$5, image=$6, source_url=$7, short_description=$8, summary=$9, includes=$10::jsonb, pickup_window=$11, transfer_included=$12, updated_at=now() WHERE id=$13 RETURNING id, slug, title, category, price, duration, location, image, source_url AS "sourceUrl", short_description AS "shortDescription", summary, includes, pickup_window AS "pickupWindow", active', [body.title, body.category, Number(body.price), body.duration, body.location, body.image, body.sourceUrl ?? null, body.shortDescription, body.summary, JSON.stringify(body.includes ?? []), body.pickupWindow, Boolean(body.transferIncluded), id])
  if (!result.rowCount) return NextResponse.json({ error: 'Tour not found.' }, { status: 404 })
  return NextResponse.json(result.rows[0])
}
