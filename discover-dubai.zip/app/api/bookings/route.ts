import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { sql } from 'drizzle-orm'

export async function POST(request: Request) {
  const body = await request.json()
  const required = ['tourSlug', 'tourName', 'customerName', 'customerEmail', 'customerPhone', 'travelDate', 'guests']
  if (required.some((key) => !body[key])) return NextResponse.json({ error: 'Please complete all required fields.' }, { status: 400 })

  const tourName = String(body.tourName).toLowerCase()
  const isQuadBike = tourName.includes('quad')
  const isBuggy = tourName.includes('buggy')
  const hasVehiclePricing = isQuadBike || isBuggy
  const vehicleQuantity = hasVehiclePricing ? Math.max(1, Math.min(20, Number(body.vehicleQuantity) || 1)) : 0
  const duration = body.vehicleDuration === '1 hour' ? '1 hour' : '30 minutes'
  const unitPrice = isQuadBike ? (duration === '1 hour' ? 300 : 150) : isBuggy ? (duration === '1 hour' ? 1500 : 1000) : 0
  const transferFee = body.transferRequested ? 250 : 0
  const totalAmount = hasVehiclePricing ? vehicleQuantity * unitPrice + transferFee : Number(body.totalAmount)
  const id = `BK-${Date.now().toString(36).toUpperCase()}`
  await db.execute(sql`INSERT INTO bookings (id, tour_slug, tour_name, customer_name, customer_email, customer_phone, travel_date, guests, notes, transfer_requested, vehicle_quantity, buggy_seats, vehicle_duration, total_amount) VALUES (${id}, ${body.tourSlug}, ${body.tourName}, ${body.customerName}, ${body.customerEmail}, ${body.customerPhone}, ${body.travelDate}, ${Number(body.guests)}, ${body.notes ?? null}, ${Boolean(body.transferRequested)}, ${vehicleQuantity}, ${isBuggy ? Number(body.buggySeats) || 2 : null}, ${hasVehiclePricing ? duration : null}, ${totalAmount})`)
  return NextResponse.json({ id, message: 'Booking request received.' }, { status: 201 })
}

export async function GET() {
  const result = await db.execute(sql`SELECT id, tour_slug AS "tourSlug", tour_name AS "tourName", customer_name AS "customerName", customer_email AS "customerEmail", customer_phone AS "customerPhone", travel_date AS "travelDate", guests, notes, transfer_requested AS "transferRequested", vehicle_quantity AS "vehicleQuantity", buggy_seats AS "buggySeats", vehicle_duration AS "vehicleDuration", status, guide_name AS "guideName", driver_name AS "driverName", total_amount AS "totalAmount", created_at AS "createdAt" FROM bookings ORDER BY created_at DESC`)
  return NextResponse.json(result.rows)
}

export async function PATCH(request: Request) {
  const body = await request.json()
  if (!body.id) return NextResponse.json({ error: 'Booking id is required.' }, { status: 400 })
  await db.execute(sql`UPDATE bookings SET guide_name = ${body.guideName || null}, driver_name = ${body.driverName || null}, status = ${body.status || 'confirmed'} WHERE id = ${body.id}`)
  return NextResponse.json({ ok: true })
}
