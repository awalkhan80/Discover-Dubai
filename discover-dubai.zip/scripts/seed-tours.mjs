import pg from 'pg'

const { Pool } = pg
const pool = new Pool({ connectionString: process.env.DATABASE_URL })
const tours = [
  ['desert-safari', 'Desert Safari', 'desert', 120, '6 hours', 'Dubai desert', 'https://images.pexels.com/photos/12379495/pexels-photo-12379495.jpeg?auto=compress&cs=tinysrgb&w=1400', 'Ride the red dunes, watch the sunset and enjoy a traditional desert camp evening.', 'Cross the red dunes at golden hour, then settle into a traditional desert camp for dinner and live entertainment.', '3:00 PM – 3:30 PM'],
  ['premium-desert-safari', 'Premium Desert Safari', 'desert', 220, '7 hours', 'Dubai desert', 'https://images.pexels.com/photos/2417260/pexels-photo-2417260.jpeg?auto=compress&cs=tinysrgb&w=1400', 'Upgrade your desert evening with private transfers, a premium camp and elevated dining.', 'A more considered desert evening with private transfers, a premium camp and a slower, more personal pace.', '3:00 PM – 3:30 PM'],
  ['dubai-city-tour', 'Dubai City Tour', 'city', 85, '8 hours', 'Dubai, UAE', 'https://images.pexels.com/photos/8319463/pexels-photo-8319463.jpeg?auto=compress&cs=tinysrgb&w=1400', 'Explore Dubai Creek, historic Al Fahidi, Palm Jumeirah and the city skyline.', 'Move from old Dubai souks to modern icons, with a local guide connecting the city’s past and present.', '8:30 AM – 9:00 AM'],
  ['abu-dhabi-city-tour', 'Abu Dhabi Grand Day', 'city', 120, '9 hours', 'Abu Dhabi, UAE', 'https://images.pexels.com/photos/15129778/pexels-photo-15129778.jpeg?auto=compress&cs=tinysrgb&w=1400', "Visit the capital's grand mosque, Corniche and cultural highlights in one day.", 'Discover grand mosques, waterfront promenades and the cultural heart of the capital in one full day.', '8:30 AM – 9:00 AM'],
  ['quad-bike', 'Quad Bike Adventure', 'desert', 150, '3 hours', 'Dubai desert', 'https://images.pexels.com/photos/26568789/pexels-photo-26568789.jpeg?auto=compress&cs=tinysrgb&w=1400', 'Take control across open dunes with a guided quad ride and desert refreshments.', 'Take the wheel across open dunes with a safety briefing, a guided route and plenty of time to ride.', '3:00 PM – 3:30 PM'],
]
for (const [slug, title, category, price, duration, location, image, shortDescription, summary, pickupWindow] of tours) {
  await pool.query('INSERT INTO tours (id,slug,title,category,price,duration,location,image,short_description,summary,pickup_window) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT (slug) DO UPDATE SET title=EXCLUDED.title,category=EXCLUDED.category,price=EXCLUDED.price,duration=EXCLUDED.duration,location=EXCLUDED.location,image=EXCLUDED.image,short_description=EXCLUDED.short_description,summary=EXCLUDED.summary,pickup_window=EXCLUDED.pickup_window,updated_at=now()', [crypto.randomUUID(), slug, title, category, price, duration, location, image, shortDescription, summary, pickupWindow])
}
await pool.end()
