import type { Metadata } from 'next'

export const siteUrl = 'https://discover-dubai.com'
export const businessName = 'Discover Dubai'
export const businessDescription = 'Trusted Dubai desert safaris, city tours, quad bike rides, dune buggy adventures and Abu Dhabi tours with convenient hotel pickup.'

export const businessSchema = {
  '@context': 'https://schema.org',
  '@type': ['LocalBusiness', 'TravelAgency'],
  name: businessName,
  legalName: 'Discover Dubai (Operated by Phoenix Travel & Tours)',
  description: businessDescription,
  url: siteUrl,
  telephone: '+971561505270',
  priceRange: 'AED 150–1500',
  address: { '@type': 'PostalAddress', streetAddress: 'Office 701, XL Tower, Business Bay', addressLocality: 'Dubai', addressCountry: 'AE' },
  areaServed: { '@type': 'City', name: 'Dubai' },
  sameAs: ['https://wa.me/971561505270']
}

export function pageMetadata(title: string, description: string, path = ''): Metadata {
  const canonical = `${siteUrl}${path}`
  return { title, description, alternates: { canonical }, openGraph: { title, description, url: canonical, siteName: businessName, type: 'website', locale: 'en_AE' }, twitter: { card: 'summary_large_image', title, description } }
}

export function jsonLd(data: Record<string, unknown>) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }} />
}
