import { betterAuth } from 'better-auth'
import { Pool } from 'pg'

const pool = new Pool({ connectionString: process.env.DATABASE_URL })

const toOrigin = (value?: string) => {
  if (!value) return undefined
  return value.startsWith('http://') || value.startsWith('https://') ? value : `https://${value}`
}

const originValues = [
  'http://localhost:3000',
  toOrigin(process.env.V0_RUNTIME_URL),
  toOrigin(process.env.V0_DEV_APP_URL),
  toOrigin(process.env.V0_BUILD_URL),
  toOrigin(process.env.V0_SANDBOX_URL),
  toOrigin(process.env.VERCEL_URL),
  toOrigin(process.env.VERCEL_PROJECT_PRODUCTION_URL),
].filter((value): value is string => Boolean(value))

const baseURL = toOrigin(process.env.BETTER_AUTH_URL) ?? toOrigin(process.env.V0_RUNTIME_URL) ?? toOrigin(process.env.VERCEL_URL)

export const auth = betterAuth({
  database: pool,
  secret: process.env.BETTER_AUTH_SECRET,
  baseURL,

  emailAndPassword: { enabled: true, disableSignUp: false },
  trustedOrigins: originValues,
  ...(process.env.NODE_ENV === 'development'
    ? {
        advanced: {
          defaultCookieAttributes: {
            sameSite: 'none' as const,
            secure: true,
          },
        },
      }
    : {}),
})
