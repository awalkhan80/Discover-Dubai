export type UserRole = 'admin' | 'customer';

export interface Tour {
  id: string;
  title: string;
  price: number;
  duration: string;
  availability: number;
  bookings: number;
  image: string;
  lastUpdated: string;
}

export interface Booking {
  id: string;
  tourTitle: string;
  date: string;
  guests: number;
  totalPrice: number;
  status: 'confirmed' | 'pending' | 'completed';
  image: string;
}

export interface Enquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  message: string;
  tourInterest: string;
  date: string;
  status: 'new' | 'responded' | 'converted';
}

// Mock admin data
export const mockTours: Tour[] = [
  {
    id: '1',
    title: 'Desert Safari',
    price: 120,
    duration: '6 hours',
    availability: 8,
    bookings: 24,
    image: 'https://images.pexels.com/photos/12379495/pexels-photo-12379495.jpeg?auto=compress&cs=tinysrgb&w=1000',
    lastUpdated: '2026-01-15',
  },
  {
    id: '2',
    title: 'Premium Desert Safari',
    price: 220,
    duration: '7 hours',
    availability: 4,
    bookings: 18,
    image: 'https://images.pexels.com/photos/2417260/pexels-photo-2417260.jpeg?auto=compress&cs=tinysrgb&w=1000',
    lastUpdated: '2026-01-14',
  },
  {
    id: '3',
    title: 'Dubai City Tour',
    price: 85,
    duration: '8 hours',
    availability: 12,
    bookings: 31,
    image: 'https://images.pexels.com/photos/8319463/pexels-photo-8319463.jpeg?auto=compress&cs=tinysrgb&w=1000',
    lastUpdated: '2026-01-15',
  },
];

export const mockBookings: Booking[] = [
  {
    id: 'BK001',
    tourTitle: 'Standard Desert Safari',
    date: '2026-10-10',
    guests: 4,
    totalPrice: 480,
    status: 'confirmed',
    image: 'https://images.pexels.com/photos/12379495/pexels-photo-12379495.jpeg?auto=compress&cs=tinysrgb&w=1000',
  },
  {
    id: 'BK002',
    tourTitle: 'Dubai City Tour',
    date: '2026-10-12',
    guests: 2,
    totalPrice: 170,
    status: 'confirmed',
    image: 'https://images.pexels.com/photos/8319463/pexels-photo-8319463.jpeg?auto=compress&cs=tinysrgb&w=1000',
  },
  {
    id: 'BK003',
    tourTitle: 'Premium Desert Safari',
    date: '2026-11-05',
    guests: 3,
    totalPrice: 660,
    status: 'pending',
    image: 'https://images.pexels.com/photos/2417260/pexels-photo-2417260.jpeg?auto=compress&cs=tinysrgb&w=1000',
  },
];

export const mockEnquiries: Enquiry[] = [
  {
    id: 'ENQ001',
    name: 'Sarah Johnson',
    email: 'sarah@example.com',
    phone: '+971 50 123 4567',
    message: 'Interested in a group tour for 8 people',
    tourInterest: 'Standard Desert Safari',
    date: '2026-01-15',
    status: 'new',
  },
  {
    id: 'ENQ002',
    name: 'Ahmed Al-Mansouri',
    email: 'ahmed@example.com',
    phone: '+971 55 987 6543',
    message: 'Looking for a private tour with family',
    tourInterest: 'Premium Desert Safari',
    date: '2026-01-14',
    status: 'responded',
  },
  {
    id: 'ENQ003',
    name: 'Emma Wilson',
    email: 'emma@example.com',
    phone: '+44 20 1234 5678',
    message: 'Corporate team building event needed',
    tourInterest: 'Dubai City Tour',
    date: '2026-01-13',
    status: 'converted',
  },
];
