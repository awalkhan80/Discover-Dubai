export type CmsPageSeed = { slug: string; title: string; description: string; template?: string }

export const existingPageCatalog: CmsPageSeed[] = [
  { slug: '', title: 'Discover Dubai', description: 'Dubai desert safari, dune buggy, quad bike, and city tour experiences.' },
  { slug: 'tours', title: 'Dubai Tours & Activities', description: 'Compare Dubai desert safaris, dune buggy rentals, quad bike adventures, and city tours.' },
  { slug: 'destinations', title: 'Dubai Destinations', description: 'Explore Dubai desert and city destinations with Discover Dubai.' },
  { slug: 'about', title: 'About Discover Dubai', description: 'Learn about Discover Dubai and Phoenix Travel & Tours.' },
  { slug: 'why-choose-us', title: 'Why Choose Discover Dubai', description: 'Reliable desert adventures with trained guides and hotel pickup.' },
  { slug: 'faq', title: 'Dubai Tours FAQ', description: 'Answers about desert safaris, buggy rentals, quad bikes, and bookings.' },
  { slug: 'contact', title: 'Contact Discover Dubai', description: 'Contact our Dubai tour team for availability and instant booking.' },
  { slug: 'privacy-policy', title: 'Privacy Policy', description: 'Discover Dubai privacy policy.' },
  { slug: 'terms', title: 'Terms & Conditions', description: 'Discover Dubai booking terms and conditions.' },
  { slug: 'dune-buggy-dubai', title: 'Dune Buggy Dubai', description: 'Book a dune buggy adventure in the Dubai desert.' },
  { slug: 'quad-bike-dubai', title: 'Quad Bike Dubai', description: 'Ride a quad bike across Dubai red dunes.' },
  { slug: 'desert-safari', title: 'Dubai Desert Safari', description: 'Book an evening or morning desert safari in Dubai.' },
  { slug: 'city-tours', title: 'Dubai City Tours', description: 'Discover Dubai city tours and private sightseeing experiences.' },
  { slug: 'abu-dhabi-city-tour', title: 'Abu Dhabi City Tour', description: 'Explore Abu Dhabi from Dubai with a guided day trip.' },
  { slug: 'desert-safari/combo-packages', title: 'Desert Safari Combo Packages', description: 'Combine desert safari, dune buggy, and quad bike experiences.' },
  { slug: 'dune-buggy-dubai/can-am-maverick', title: 'Can-Am Maverick Dubai', description: 'Ride a Can-Am Maverick X3 across Dubai desert dunes.' },
  { slug: 'dune-buggy-dubai/polaris-rzr', title: 'Polaris RZR Dubai', description: 'Drive a Polaris RZR 1000cc sport buggy in Dubai.' },
  { slug: 'dune-buggy-dubai/4-seater', title: '4-Seater Buggy Dubai', description: 'Share a four-seater dune buggy adventure with your group.' },
  { slug: 'quad-bike-dubai/atv-rental', title: 'ATV Rental Dubai', description: 'Rent an ATV quad bike for a guided desert ride.' },
  { slug: 'desert-safari/evening-safari', title: 'Evening Desert Safari Dubai', description: 'Enjoy sunset dunes, live entertainment, dinner, and pickup.' },
  { slug: 'desert-safari/morning-safari', title: 'Morning Desert Safari Dubai', description: 'Start your day with a morning desert safari and dune adventure.' },
  { slug: 'city-tours/dubai-city-tour', title: 'Dubai City Tour', description: 'See Dubai landmarks on a guided city sightseeing tour.' },
  { slug: 'abu-dhabi-city-tour/day-trip', title: 'Abu Dhabi Day Trip', description: 'Visit Abu Dhabi landmarks on a full-day trip from Dubai.' },
  { slug: 'tours/can-am-maverick-buggy', title: 'Can-Am Maverick Dune Buggy Rental Dubai', description: 'Book a 1000cc turbo Can-Am Maverick dune buggy experience.' },
  { slug: 'tours/polaris-rzr-buggy', title: 'Polaris RZR Sport Buggy Dubai', description: 'Book a Polaris RZR 1000cc Sport Buggy desert adventure.' },
  { slug: 'tours/quad-bike-adventure', title: 'Quad Bike Adventure Dubai', description: 'Ride a Yamaha Raptor or quad bike across red dunes.' },
  { slug: 'tours/evening-desert-safari', title: 'Evening Desert Safari Dubai', description: 'Book an evening desert safari with dinner and entertainment.' },
]

export const cmsPath = (slug: string) => slug ? `/${slug}` : '/'
export const cmsTitle = (slug: string) => existingPageCatalog.find((page) => page.slug === slug)?.title ?? slug
