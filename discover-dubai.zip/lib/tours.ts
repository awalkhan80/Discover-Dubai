export type TourDetail = {
  slug: string
  title: string
  price: number
  duration: string
  location: string
  image: string
  sourceUrl: string
  summary: string
  shortDescription: string
  includes: string[]
  transferIncluded?: boolean
}

export const tours: TourDetail[] = [
  { slug: 'desert-safari', title: 'Desert Safari', price: 120, duration: '6 hours', location: 'Dubai desert', shortDescription: 'Ride the red dunes, watch the sunset and enjoy a traditional desert camp evening.', image: 'https://images.pexels.com/photos/12379495/pexels-photo-12379495.jpeg?auto=compress&cs=tinysrgb&w=1400', sourceUrl: 'https://www.pexels.com/photo/photo-of-white-cars-on-a-desert-12379495/', summary: 'Cross the red dunes at golden hour, then settle into a traditional desert camp for dinner and live entertainment.', includes: ['Dune bashing in a 4x4', 'Sunset photo stop', 'BBQ dinner and refreshments', 'Henna and live shows'], pickupWindow: '3:00 PM – 3:30 PM' },
  { slug: 'premium-desert-safari', title: 'Premium Desert Safari', price: 220, duration: '7 hours', location: 'Dubai desert', shortDescription: 'Upgrade your desert evening with private transfers, a premium camp and elevated dining.', image: 'https://images.pexels.com/photos/2417260/pexels-photo-2417260.jpeg?auto=compress&cs=tinysrgb&w=1400', sourceUrl: 'https://www.pexels.com/photo/white-suv-on-dessert-2417260', summary: 'A more considered desert evening with private transfers, a premium camp and a slower, more personal pace.', includes: ['Private hotel pickup', 'Premium 4x4 dune drive', 'Gourmet camp dinner', 'Reserved lounge seating'], pickupWindow: '3:00 PM – 3:30 PM' },
  { slug: 'dubai-city-tour', title: 'Dubai City Tour', price: 85, duration: '8 hours', location: 'Dubai, UAE', shortDescription: 'Explore Dubai Creek, historic Al Fahidi, Palm Jumeirah and the city skyline.', image: 'https://images.pexels.com/photos/8319463/pexels-photo-8319463.jpeg?auto=compress&cs=tinysrgb&w=1400', sourceUrl: 'https://www.pexels.com/photo/hotel-atlantis-in-dubai-at-sunset-8319463', summary: 'Move from old Dubai souks to modern icons, with a local guide connecting the city’s past and present.', includes: ['Hotel pickup and drop-off', 'Dubai Creek and Al Fahidi', 'Burj Khalifa photo stop', 'Palm Jumeirah and Atlantis'], pickupWindow: '8:30 AM – 9:00 AM' },
  { slug: 'abu-dhabi-city-tour', title: 'Abu Dhabi Grand Day', price: 120, duration: '9 hours', location: 'Abu Dhabi, UAE', shortDescription: "Visit the capital's grand mosque, Corniche and cultural highlights in one day.", image: 'https://images.pexels.com/photos/15129778/pexels-photo-15129778.jpeg?auto=compress&cs=tinysrgb&w=1400', sourceUrl: 'https://www.pexels.com/photo/gold-and-marble-domes-of-mosque-15129778/', summary: 'Discover grand mosques, waterfront promenades and the cultural heart of the capital in one full day.', includes: ['Return transport from Dubai', 'Sheikh Zayed Grand Mosque', 'Corniche photo stop', 'Local lunch recommendation'], pickupWindow: '8:30 AM – 9:00 AM' },
  { slug: 'quad-bike', title: 'Quad Bike Adventure', price: 150, duration: '3 hours', location: 'Dubai desert', shortDescription: 'Take control across open dunes with a guided quad ride and desert refreshments.', image: 'https://images.pexels.com/photos/26568789/pexels-photo-26568789.jpeg?auto=compress&cs=tinysrgb&w=1400', sourceUrl: 'https://www.pexels.com/photo/mother-and-son-riding-quads-on-desert-26568789/', summary: 'Take the wheel across open dunes with a safety briefing, a guided route and plenty of time to ride.', includes: ['Safety briefing and helmet', 'Guided quad bike session', 'Desert refreshments', 'Photo opportunities'], pickupWindow: '3:00 PM – 3:30 PM' },
]

export function getTour(slug: string) { return tours.find((tour) => tour.slug === slug) }
