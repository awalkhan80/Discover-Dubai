export type CmsBlock = { type: 'rich_text' | 'hero' | 'comparison_table' | 'faq' | 'cta'; body?: string; data?: Record<string, unknown> }
export type CmsSeo = { title: string; description: string; canonical?: string; noindex?: boolean; ogImage?: string }
export type CmsPageStatus = 'draft' | 'published' | 'scheduled'
export type CmsPage = { id: string; slug: string; title: string; status: CmsPageStatus; template: string; content: { blocks: CmsBlock[] }; seo: CmsSeo }
