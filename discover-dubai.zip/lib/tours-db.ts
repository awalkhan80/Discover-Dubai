import { pool } from '@/lib/db'
import type { TourDetail } from '@/lib/tours'

export async function getPersistedTours(): Promise<TourDetail[]> {
  const result = await pool.query('SELECT slug,title,price,duration,location,image,source_url AS "sourceUrl",short_description AS "shortDescription",summary,includes,pickup_window AS "pickupWindow",transfer_included AS "transferIncluded" FROM tours WHERE active=true ORDER BY created_at DESC')
  return result.rows
}

export async function getPersistedTour(slug: string): Promise<TourDetail | undefined> {
  const result = await pool.query('SELECT slug,title,price,duration,location,image,source_url AS "sourceUrl",short_description AS "shortDescription",summary,includes,pickup_window AS "pickupWindow",transfer_included AS "transferIncluded" FROM tours WHERE slug=$1 AND active=true LIMIT 1', [slug])
  return result.rows[0]
}
