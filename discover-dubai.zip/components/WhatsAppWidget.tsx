'use client'

import { MessageCircle, X } from 'lucide-react'
import { useEffect, useState } from 'react'

const whatsappUrl = 'https://wa.me/971561505270?text=Hello%20Discover%20Travel%20%26%20Tours%2C%20I%27d%20like%20help%20planning%20a%20Dubai%20tour.'

export function WhatsAppWidget() {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const timer = window.setTimeout(() => setOpen(true), 4500)
    return () => window.clearTimeout(timer)
  }, [])

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3">
      {open && (
        <div className="w-[min(20rem,calc(100vw-2rem))] rounded-2xl border border-border bg-card p-4 text-card-foreground shadow-2xl" role="dialog" aria-label="WhatsApp chat invitation">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm font-bold">Plan your Dubai experience</p>
              <p className="mt-1 text-sm leading-6 text-muted-foreground">Chat with Discover Dubai about availability, pickup, and the best safari for your trip.</p>
            </div>
            <button type="button" onClick={() => setOpen(false)} className="rounded-full p-1 text-muted-foreground hover:bg-secondary hover:text-foreground" aria-label="Close WhatsApp message">
              <X size={16} />
            </button>
          </div>
          <a href={whatsappUrl} target="_blank" rel="noreferrer" className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-[#25D366] px-4 py-3 text-sm font-bold text-white hover:brightness-95">
            <MessageCircle size={18} /> Chat on WhatsApp
          </a>
        </div>
      )}
      <a href={whatsappUrl} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-full bg-[#25D366] px-4 py-3 text-sm font-bold text-white shadow-lg shadow-[#25D366]/25 transition hover:-translate-y-0.5 hover:brightness-95" aria-label="Chat with Discover Travel and Tours on WhatsApp">
        <MessageCircle size={21} /> <span className="hidden sm:inline">WhatsApp us</span>
      </a>
    </div>
  )
}
