'use client'

import Link from 'next/link'
import { useState } from 'react'
import { ShieldCheck, UserRound } from 'lucide-react'
import DashboardLayout from '@/components/DashboardLayout'
import AdminDashboard from '@/components/AdminDashboard'
import CustomerDashboard from '@/components/CustomerDashboard'
import type { UserRole } from '@/lib/dashboard-data'
import { authClient } from '@/lib/auth-client'

export default function DashboardPageClient({ userName }: { userName: string }) {
  const [role, setRole] = useState<UserRole>('admin')

  async function signOut() {
    await authClient.signOut()
    window.location.href = '/sign-in'
  }

  return (
    <DashboardLayout role={role}>
      <div className="mb-8 flex flex-col gap-4 rounded-2xl border border-border bg-secondary/30 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs font-bold uppercase tracking-[.16em] text-primary">Operations workspace</p>
          <p className="mt-1 text-sm text-muted-foreground">Signed in as {userName}. Manage every guest journey from one place.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-full border border-border bg-card p-1">
            <button onClick={() => setRole('admin')} className={`flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition ${role === 'admin' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}><ShieldCheck size={14} /> Admin</button>
            <button onClick={() => setRole('customer')} className={`flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition ${role === 'customer' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}><UserRound size={14} /> Customer</button>
          </div>
          <Link href="/dashboard/pages" className="rounded-full border border-border px-4 py-2 text-xs font-bold text-muted-foreground hover:text-foreground">Pages CMS</Link>
          <button onClick={signOut} className="rounded-full border border-border px-4 py-2 text-xs font-bold text-muted-foreground hover:text-foreground">Sign out</button>
        </div>
      </div>
      {role === 'admin' ? <AdminDashboard /> : <CustomerDashboard />}
    </DashboardLayout>
  )
}
