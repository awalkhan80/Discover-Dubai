'use client'

import { useState, useTransition } from 'react'
import { archiveCmsPage, createCmsPage, deleteCmsPage, importExistingPages, publishCmsPage, updateCmsPage } from '@/app/actions/cms'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Eye, FileDown, Plus, Save, Send, Trash2 } from 'lucide-react'

type CmsPage = { id: string; title: string; slug: string; status: string; template: string; updated_at: string; description?: string }

export default function PagesCms({ initialPages }: { initialPages: CmsPage[] }) {
  const [pages, setPages] = useState(initialPages)
  const [selected, setSelected] = useState<CmsPage | null>(initialPages[0] ?? null)
  const [title, setTitle] = useState(selected?.title ?? '')
  const [slug, setSlug] = useState(selected?.slug ?? '')
  const [body, setBody] = useState(selected?.description ?? '')
  const [seoTitle, setSeoTitle] = useState(selected?.title ?? '')
  const [seoDescription, setSeoDescription] = useState(selected?.description ?? '')
  const [query, setQuery] = useState('')
  const [isPending, startTransition] = useTransition()
  const visiblePages = pages.filter((page) => `${page.title} ${page.slug}`.toLowerCase().includes(query.toLowerCase()))

  const selectPage = (page: CmsPage) => { setSelected(page); setTitle(page.title); setSlug(page.slug); setBody(page.description ?? ''); setSeoTitle(page.title); setSeoDescription(page.description ?? '') }
  const save = () => selected && startTransition(async () => { await updateCmsPage({ id: selected.id, title, slug, content: { blocks: [{ type: 'rich_text', body }] }, seo: { title: seoTitle, description: seoDescription } }); setPages((current) => current.map((page) => page.id === selected.id ? { ...page, title, slug, description: body, status: 'draft' } : page)) })
  const publish = () => selected && startTransition(async () => { await publishCmsPage(selected.id); setPages((current) => current.map((page) => page.id === selected.id ? { ...page, status: 'published' } : page)) })
  const remove = () => selected && window.confirm(selected.status === 'published' ? 'Archive this published page and redirect its URL to the homepage?' : 'Permanently delete this draft?') && startTransition(async () => { if (selected.status === 'published') await archiveCmsPage(selected.id); else await deleteCmsPage(selected.id); setPages((current) => current.filter((page) => page.id !== selected.id)); setSelected(null) })
  const importPages = () => startTransition(async () => { await importExistingPages(); window.location.reload() })
  const create = () => startTransition(async () => { await createCmsPage({ title: 'New landing page', slug: `new-page-${Date.now()}`, template: 'landing' }); window.location.reload() })

  return <div className="grid gap-6 lg:grid-cols-[300px_minmax(0,1fr)]">
    <Card className="h-fit"><CardHeader className="gap-4"><div className="flex items-center justify-between"><CardTitle className="text-base">Existing pages</CardTitle><Button size="icon" variant="outline" onClick={create} aria-label="Create page"><Plus /></Button></div><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search pages or URLs" /></CardHeader><CardContent className="flex flex-col gap-2">{visiblePages.map((page) => <button key={page.id} onClick={() => selectPage(page)} className={`flex items-center justify-between gap-3 rounded-lg px-3 py-3 text-left text-sm transition ${selected?.id === page.id ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'}`}><span className="min-w-0"><span className="block truncate font-medium">{page.title}</span><span className={`block truncate text-xs ${selected?.id === page.id ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>/{page.slug}</span></span><Badge variant={selected?.id === page.id ? 'secondary' : 'outline'}>{page.status}</Badge></button>)}{visiblePages.length === 0 && <p className="text-sm text-muted-foreground">No pages imported yet.</p>}<Button variant="outline" onClick={importPages} disabled={isPending}><FileDown data-icon="inline-start" />Import existing routes</Button></CardContent></Card>
    <Card><CardHeader className="flex flex-col gap-4 border-b sm:flex-row sm:items-center sm:justify-between"><div><p className="text-sm text-muted-foreground">Editing existing website page</p><CardTitle>{selected ? title : 'Select a page'}</CardTitle>{selected && <p className="mt-1 text-xs text-muted-foreground">/{selected.slug}</p>}</div>{selected && <div className="flex flex-wrap gap-2"><Button variant="outline" asChild><a href={selected.slug ? `/${selected.slug}` : '/'} target="_blank" rel="noreferrer"><Eye data-icon="inline-start" />Preview</a></Button><Button variant="outline" onClick={save} disabled={isPending}><Save data-icon="inline-start" />Save draft</Button><Button onClick={publish} disabled={isPending || selected.status === 'archived'}><Send data-icon="inline-start" />Publish</Button><Button variant="destructive" onClick={remove} disabled={isPending}><Trash2 data-icon="inline-start" />{selected.status === 'published' ? 'Archive' : 'Delete'}</Button></div>}</CardHeader>{selected && <CardContent className="pt-6"><Tabs defaultValue="content"><TabsList><TabsTrigger value="content">Content</TabsTrigger><TabsTrigger value="seo">SEO</TabsTrigger></TabsList><TabsContent value="content" className="flex flex-col gap-6 pt-6"><div className="grid gap-4 md:grid-cols-2"><label className="flex flex-col gap-2 text-sm font-medium">Page title<Input value={title} onChange={(event) => setTitle(event.target.value)} /></label><label className="flex flex-col gap-2 text-sm font-medium">URL slug<Input value={slug} onChange={(event) => setSlug(event.target.value)} /></label></div><label className="flex flex-col gap-2 text-sm font-medium">Page content<Textarea value={body} onChange={(event) => setBody(event.target.value)} placeholder="Edit the existing page content here..." className="min-h-72" /></label></TabsContent><TabsContent value="seo" className="flex flex-col gap-4 pt-6"><label className="flex flex-col gap-2 text-sm font-medium">SEO title<Input value={seoTitle} onChange={(event) => setSeoTitle(event.target.value)} /></label><label className="flex flex-col gap-2 text-sm font-medium">Meta description<Textarea value={seoDescription} onChange={(event) => setSeoDescription(event.target.value)} /></label><div className="rounded-lg border bg-muted/30 p-4"><p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Search preview</p><p className="mt-2 text-lg text-primary">{seoTitle || title}</p><p className="text-sm text-muted-foreground">discover-dubai.com/{slug}</p><p className="mt-1 text-sm">{seoDescription || 'Add a description for search engines.'}</p></div></TabsContent></Tabs></CardContent>}</Card>
  </div>
}
