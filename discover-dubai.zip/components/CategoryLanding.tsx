import Link from 'next/link'
import { ArrowRight, CheckCircle2, Clock3, MapPin } from 'lucide-react'
import { pageMetadata, siteUrl, jsonLd } from '@/lib/seo'

type CategoryLandingProps = {
  title: string
  description: string
  eyebrow: string
  intro: string
  highlights: string[]
  links: { label: string; href: string }[]
  faqs: { question: string; answer: string }[]
}

export function CategoryLanding({ title, description, eyebrow, intro, highlights, links, faqs }: CategoryLandingProps) {
  const schema = { '@context': 'https://schema.org', '@graph': [{ '@type': 'Service', name: title, description, provider: { '@type': 'TravelAgency', name: 'Discover Dubai', url: siteUrl, telephone: '+971561505270' }, areaServed: { '@type': 'City', name: 'Dubai' }, url: `${siteUrl}${typeof window === 'undefined' ? '' : ''}` }, { '@type': 'FAQPage', mainEntity: faqs.map((faq) => ({ '@type': 'Question', name: faq.question, acceptedAnswer: { '@type': 'Answer', text: faq.answer } })) }] }
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} /><main className="min-h-screen bg-background text-foreground"><header className="navy-band border-b border-primary/20"><div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 lg:px-10"><Link href="/" aria-label="Discover Dubai home"><img src="/discover-dubai-logo.png" alt="Discover Dubai" className="h-11 w-auto" /></Link><Link href="/contact" className="rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground">Contact us</Link></div></header><div className="mx-auto max-w-7xl px-5 py-14 lg:px-10"><p className="eyebrow">{eyebrow}</p><h1 className="mt-3 max-w-4xl font-serif text-5xl leading-tight md:text-7xl">{title}</h1><p className="mt-6 max-w-3xl text-lg leading-8 text-muted-foreground">{intro}</p><div className="mt-8 flex flex-wrap gap-4"><Link href="/tours" className="rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground">Check availability <ArrowRight className="ml-2 inline" size={16} /></Link><a href="https://wa.me/971561505270" className="rounded-full border border-border px-6 py-3 text-sm font-bold">WhatsApp us</a></div><div className="mt-14 grid gap-5 md:grid-cols-3">{highlights.map((highlight) => <div key={highlight} className="rounded-2xl border border-border bg-card p-5"><CheckCircle2 className="text-primary" size={20} /><p className="mt-4 font-semibold leading-6">{highlight}</p></div>)}</div><section className="mt-16 grid gap-10 lg:grid-cols-[1.1fr_.9fr]"><div><h2 className="font-serif text-3xl">Explore {title}</h2><div className="mt-5 grid gap-3">{links.map((link) => <Link key={link.href} href={link.href} className="flex items-center justify-between rounded-xl border border-border bg-card px-5 py-4 font-semibold hover:border-primary">{link.label}<ArrowRight size={18} className="text-primary" /></Link>)}</div><h2 className="mt-12 font-serif text-3xl">Plan your experience</h2><div className="mt-5 grid gap-4 text-sm leading-7 text-muted-foreground"><p><Clock3 className="mr-2 inline text-primary" size={16} />Choose a duration that suits your group, with clear AED pricing shown before booking.</p><p><MapPin className="mr-2 inline text-primary" size={16} />Pickup can be arranged from hotels and central Dubai locations. Confirm your area with our team.</p><p>{description}</p></div></div><div><h2 className="font-serif text-3xl">Frequently asked questions</h2><div className="mt-5 grid gap-5">{faqs.map((faq) => <details key={faq.question} className="rounded-xl border border-border bg-card p-5"><summary className="cursor-pointer font-semibold">{faq.question}</summary><p className="mt-3 text-sm leading-6 text-muted-foreground">{faq.answer}</p></details>)}</div></div></section></div></main></>
}

export function categoryMetadata(title: string, description: string, path: string) { return pageMetadata(title, description, path) }
