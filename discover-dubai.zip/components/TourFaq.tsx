"use client";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const tourFaqs = [
  { question: "Do I need a driving license to drive a dune buggy in Dubai?", answer: "No international or UAE driving license is required. Full safety briefing and helmets and goggles are provided." },
  { question: "What should I wear for a dune buggy ride in Dubai?", answer: "Wear comfortable, lightweight clothing, closed-toe shoes, UV sunglasses, and sunscreen. A scarf or bandana is recommended for blowing sand." },
  { question: "How much does a dune buggy rental cost in Dubai?", answer: "Prices start from AED 1,000 for a 2-seater Polaris RZR and AED 1,350 for a high-performance Can-Am Maverick." },
  { question: "Is hotel pickup and drop-off included?", answer: "Yes, complimentary pickup and drop-off from Dubai and Sharjah hotels is included with all major packages." },
  { question: "What is the minimum age to drive a buggy?", answer: "Drivers must be at least 16 years old. Passengers can be 5 years and older." },
];

export function TourFaq() {
  return (
    <section aria-labelledby="tour-faq-heading" className="rounded-3xl border border-border bg-card p-6 sm:p-8">
      <h2 id="tour-faq-heading" className="font-serif text-3xl text-foreground">Frequently asked questions</h2>
      <Accordion type="single" collapsible className="mt-5">
        {tourFaqs.map((faq, index) => (
          <AccordionItem key={faq.question} value={`faq-${index}`}>
            <AccordionTrigger className="text-left text-base">{faq.question}</AccordionTrigger>
            <AccordionContent className="leading-7 text-muted-foreground">{faq.answer}</AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </section>
  );
}

export function TourFaqSchema() {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({ "@context": "https://schema.org", "@type": "FAQPage", mainEntity: tourFaqs.map((faq) => ({ "@type": "Question", name: faq.question, acceptedAnswer: { "@type": "Answer", text: faq.answer } })) }) }} />;
}

export function TourExperienceSchema({ name, description, price, url }: { name: string; description: string; price: number; url: string }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify({ "@context": "https://schema.org", "@type": ["TouristTrip", "Product"], name, description, url, provider: { "@type": "TravelAgency", name: "Discover Dubai", legalName: "Discover Dubai (Operated by Phoenix Travel & Tours)", url: "https://discover-dubai.com" }, itinerary: { "@type": "ItemList", itemListElement: [{ "@type": "ListItem", position: 1, name: "Hotel pickup and desert arrival" }, { "@type": "ListItem", position: 2, name: "Safety briefing and guided ride" }, { "@type": "ListItem", position: 3, name: "Return transfer" }] }, offers: { "@type": "Offer", price, priceCurrency: "AED", availability: "https://schema.org/InStock", url } }) }} />;
}
