'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ArrowRight, LogOut, Menu, X } from 'lucide-react';
import type { UserRole } from '@/lib/dashboard-data';

interface DashboardLayoutProps {
  children: React.ReactNode;
  role: UserRole;
}

export default function DashboardLayout({ children, role }: DashboardLayoutProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  const isAdmin = role === 'admin';
  const navItems = isAdmin
    ? [
        { label: 'Tours', href: '#tours-section' },
        { label: 'Bookings', href: '#bookings-section' },
        { label: 'Enquiries', href: '#enquiries-section' },
      ]
    : [
        { label: 'My Bookings', href: '#bookings-section' },
        { label: 'Saved Tours', href: '#saved-section' },
        { label: 'My Enquiries', href: '#enquiries-section' },
      ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-slate-400 bg-slate-500 text-white shadow-sm">
        <div className="mx-auto max-w-7xl px-5 py-4 lg:px-10">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3">
              <img src="/discover-dubai-logo.png" alt="Discover Dubai" className="h-10 w-auto object-contain" />
              <span className="font-serif text-lg tracking-[.12em]">DASHBOARD</span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-8">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-sm font-medium text-white transition hover:text-slate-100"
                >
                  {item.label}
                </a>
              ))}
              <div className="border-l border-border pl-8 flex items-center gap-4">
                <span className="text-xs font-semibold text-primary uppercase tracking-wider">
                  {isAdmin ? 'Admin' : 'Customer'}
                </span>
                <Link
                  href="/"
                  className="flex items-center gap-2 rounded-full bg-secondary px-4 py-2 text-xs font-bold transition hover:bg-secondary/80"
                >
                  <LogOut size={14} /> Exit
                </Link>
              </div>
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden rounded-full border border-border p-2"
              aria-label="Toggle menu"
            >
              {menuOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {menuOpen && (
            <div className="mt-4 flex flex-col gap-4 border-t border-border pt-4">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  className="text-sm font-medium text-white transition hover:text-slate-100"
                >
                  {item.label}
                </a>
              ))}
              <div className="flex flex-col gap-3 border-t border-border pt-4">
                <span className="text-xs font-semibold text-primary uppercase tracking-wider">
                  {isAdmin ? 'Admin' : 'Customer'}
                </span>
                <Link
                  href="/"
                  className="flex items-center justify-center gap-2 rounded-full bg-secondary px-4 py-2 text-xs font-bold transition hover:bg-secondary/80"
                >
                  <LogOut size={14} /> Exit Dashboard
                </Link>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-7xl px-5 py-10 lg:px-10">{children}</main>

      {/* Footer */}
      <footer className="border-t border-border bg-secondary/30 px-5 py-8 mt-12 lg:px-10">
        <div className="mx-auto max-w-7xl flex flex-col justify-between gap-6 md:flex-row md:items-center text-sm text-muted-foreground">
          <div>
            <p className="font-serif text-lg tracking-[.12em] text-foreground">DISCOVER DUBAI</p>
            <p className="mt-1">Manage your UAE experiences</p>
          </div>
          <Link
            href="/"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2 text-xs font-bold text-primary-foreground transition hover:brightness-110"
          >
            Back to site <ArrowRight size={14} />
          </Link>
        </div>
      </footer>
    </div>
  );
}
