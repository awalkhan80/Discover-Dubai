import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const rows = [
  ["Yamaha Raptor 700cc Quad Bike", "700 CC", "1 Person", "60 Mins", "AED 300", "/tours/quad-bike-adventure"],
  ["Polaris RZR Sport EPS", "1000 CC", "2 Seater", "60 Mins", "AED 1,000", "/tours/polaris-rzr-buggy"],
  ["Polaris RZR Pro R 4-Seater", "1000 CC", "4 Seater", "60 Mins", "AED 1,500", "/dune-buggy-dubai/4-seater"],
  ["Can-Am Maverick X3 / R X rs", "1000 CC Turbo", "2–4 Seater", "60 Mins", "AED 1,350", "/tours/can-am-maverick-buggy"],
  ["Desert Safari + Quad Bike Combo", "350–700 CC", "1–2 Persons", "6 Hours", "AED 399", "/desert-safari/combo-packages"],
];

export function TourComparisonTable() {
  return <div className="overflow-x-auto rounded-3xl border border-border bg-card"><table className="w-full min-w-[760px] text-left text-sm"><caption className="sr-only">Dubai buggy, quad bike, and desert safari starting prices</caption><thead className="bg-secondary text-secondary-foreground"><tr>{["Buggy / Quad Model", "Engine CC / Power", "Seater Capacity", "Duration", "Starting Price (AED)", "Action"].map((heading) => <th key={heading} scope="col" className="px-5 py-4 font-semibold">{heading}</th>)}</tr></thead><tbody>{rows.map(([model, engine, seats, duration, price, href]) => <tr key={model} className="border-t border-border"><th scope="row" className="px-5 py-5 font-medium">{model}</th><td className="px-5 py-5 text-muted-foreground">{engine}</td><td className="px-5 py-5 text-muted-foreground">{seats}</td><td className="px-5 py-5 text-muted-foreground">{duration}</td><td className="px-5 py-5 font-semibold text-primary">{price}</td><td className="px-5 py-5"><Button asChild size="sm"><Link href={href}>Book now <ArrowUpRight data-icon="inline-end" /></Link></Button></td></tr>)}</tbody></table></div>;
}
