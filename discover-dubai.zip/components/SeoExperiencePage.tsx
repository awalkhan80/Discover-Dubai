import Link from 'next/link'
import { ArrowRight, CheckCircle2 } from 'lucide-react'
import { jsonLd, pageMetadata, siteUrl } from '@/lib/seo'

type Row = { option: string; duration: string; price: string }
type FAQ = { question: string; answer: string }

type Props = {
  title: string
  description: string
  path: string
  eyebrow: string
  intro: string
  highlights: string[]
  rows: Row[]
  faqs: FAQ[]
  related: { label: string; href: string }[]
  schemaType?: 'TouristTrip' | 'Service'
}

export function SeoExperiencePage({ title, description, path, eyebrow, intro, highlights, rows, faqs, related, schemaType = 'TouristTrip' }: Props) {
  const schema = { '@context': 'https://schema.org', '@graph': [{ '@type': schemaType, name: title, description, url: `${siteUrl}${path}`, provider: { '@type': 'TravelAgency', name: 'Discover Dubai', telephone: '+971561505270', url: siteUrl }, areaServed: { '@type': 'City', name: 'Dubai' }, offers: rows.map((row) => ({ '@type': 'Offer', name: row.option, price: row.price.replace(/[^0-9.]/g, ''), priceCurrency: 'AED', availability: 'https://schema.org/InStock', url: `${siteUrl}${path}` })) }, { '@type': 'FAQPage', mainEntity: faqs.map((faq) => ({ '@type': 'Question', name: faq.question, acceptedAnswer: { '@type': 'Answer', text: faq.answer } })) }, { '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Home', item: siteUrl }, { '@type': 'ListItem', position: 2, name: title, item: `${siteUrl}${path}` }] }] }
  return <><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} /><main className="min-h-screen bg-background text-foreground"><header className="navy-band border-b border-primary/20"><div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 lg:px-10"><Link href="/" aria-label="Discover Dubai home"><img src="/discover-dubai-logo.png" alt="Discover Dubai" width={176} height={44} className="h-11 w-auto" /></Link><Link href="/contact" className="rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground">Contact us</Link></div></header><div className="mx-auto max-w-7xl px-5 py-14 lg:px-10"><p className="eyebrow">{eyebrow}</p><h1 className="mt-3 max-w-4xl font-serif text-5xl leading-tight md:text-7xl">{title}</h1><p className="mt-6 max-w-3xl text-lg leading-8 text-muted-foreground">{intro}</p><div className="mt-8 flex flex-wrap gap-4"><Link href="/tours" className="rounded-full bg-primary px-6 py-3 text-sm font-bold text-primary-foreground">Check availability <ArrowRight className="ml-2 inline" size={16} /></Link><a href="https://wa.me/971561505270" className="rounded-full border border-border px-6 py-3 text-sm font-bold">WhatsApp us</a></div><div className="mt-14 grid gap-5 md:grid-cols-3">{highlights.map((item) => <div key={item} className="rounded-2xl border border-border bg-card p-5"><CheckCircle2 className="text-primary" size={20} /><p className="mt-4 font-semibold leading-6">{item}</p></div>)}</div><section className="mt-16"><h2 className="font-serif text-3xl">{title} pricing</h2><p className="mt-3 max-w-2xl leading-7 text-muted-foreground">Compare available options before you book. Prices are starting rates and may vary by date, vehicle availability, pickup and group size.</p><div className="mt-6 overflow-hidden rounded-2xl border border-border"><table className="w-full text-left text-sm"><thead className="bg-muted"><tr><th className="px-5 py-4 font-bold">Option</th><th className="px-5 py-4 font-bold">Duration</th><th className="px-5 py-4 font-bold">From</th></tr></thead><tbody>{rows.map((row) => <tr key={row.option} className="border-t border-border"><td className="px-5 py-4 font-semibold">{row.option}</td><td className="px-5 py-4 text-muted-foreground">{row.duration}</td><td className="px-5 py-4 font-bold text-primary">{row.price}</td></tr>)}</tbody></table></div></section><section className="mt-16 grid gap-10 lg:grid-cols-2"><div><h2 className="font-serif text-3xl">Frequently asked questions</h2><div className="mt-5 space-y-3">{faqs.map((faq) => <details key={faq.question} className="rounded-xl border border-border bg-card p-5"><summary className="cursor-pointer font-semibold">{faq.question}</summary><p className="mt-3 leading-7 text-muted-foreground">{faq.answer}</p></details>)}</div></div><div><h2 className="font-serif text-3xl">Explore more Dubai tours</h2><div className="mt-5 space-y-3">{related.map((link) => <Link key={link.href} href={link.href} className="flex items-center justify-between rounded-xl border border-border bg-card px-5 py-4 font-semibold hover:border-primary">{link.label}<ArrowRight size={18} className="text-primary" /></Link>)}</div></div></section></div></main></>
}

export function seoExperienceMetadata(title: string, description: string, path: string) { return pageMetadata(`${title} | Discover Dubai`, description, path) }
export { jsonLd }
