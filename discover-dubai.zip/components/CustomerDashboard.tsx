'use client';

import { useState } from 'react';
import { Heart, Calendar, Users, MessageSquare, Clock3 } from 'lucide-react';
import type { Booking, Tour, Enquiry } from '@/lib/dashboard-data';
import { mockBookings, mockTours, mockEnquiries } from '@/lib/dashboard-data';

export default function CustomerDashboard() {
  const [bookings] = useState<Booking[]>(mockBookings);
  const [savedTours, setSavedTours] = useState<Tour[]>([mockTours[0], mockTours[1]]);
  const [enquiries] = useState<Enquiry[]>(mockEnquiries.slice(0, 2));

  const upcomingBookings = bookings.filter((b) => new Date(b.date) > new Date());
  const completedBookings = bookings.filter((b) => new Date(b.date) <= new Date());

  return (
    <div className="space-y-10">
      {/* Welcome Section */}
      <div>
        <h1 className="section-title mb-2">Welcome back!</h1>
        <p className="text-lg text-muted-foreground">Manage your bookings and explore more adventures</p>
      </div>

      {/* Upcoming Bookings */}
      <section id="bookings-section">
        <h2 className="mb-6 font-serif text-3xl">Upcoming Adventures</h2>
        {upcomingBookings.length > 0 ? (
          <div className="space-y-4">
            {upcomingBookings.map((booking) => (
              <div key={booking.id} className="rounded-2xl border border-border bg-card overflow-hidden">
                <div className="flex flex-col sm:flex-row">
                  <img src={booking.image} alt={booking.tourTitle} className="h-48 w-full object-cover sm:h-40 sm:w-40" />
                  <div className="flex-1 p-6 flex flex-col justify-between">
                    <div>
                      <h3 className="font-serif text-2xl">{booking.tourTitle}</h3>
                      <div className="mt-4 space-y-2 text-sm">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Calendar size={16} />
                          <span>{booking.date}</span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Users size={16} />
                          <span>{booking.guests} guests</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-6 flex flex-wrap gap-3">
                      <button className="rounded-full bg-primary px-5 py-2 text-xs font-bold text-primary-foreground transition hover:brightness-110">
                        View Details
                      </button>
                      <button className="rounded-full border border-border px-5 py-2 text-xs font-bold transition hover:bg-secondary">
                        Modify Booking
                      </button>
                    </div>
                  </div>
                  <div className="px-6 py-4 sm:py-6 text-right">
                    <p className="text-xs text-muted-foreground">Total</p>
                    <p className="mt-1 text-2xl font-bold text-primary">AED {booking.totalPrice}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-border bg-card p-10 text-center">
            <p className="text-muted-foreground">No upcoming bookings yet. Explore tours now!</p>
          </div>
        )}
      </section>

      {/* Booking History */}
      <section>
        <h2 className="mb-6 font-serif text-3xl">Past Adventures</h2>
        {completedBookings.length > 0 ? (
          <div className="space-y-3">
            {completedBookings.map((booking) => (
              <div key={booking.id} className="rounded-2xl border border-border bg-card p-4 flex flex-col sm:flex-row sm:items-center gap-4">
                <img src={booking.image} alt={booking.tourTitle} className="h-16 w-16 rounded-lg object-cover" />
                <div className="flex-1">
                  <p className="font-semibold">{booking.tourTitle}</p>
                  <p className="text-xs text-muted-foreground mt-1">{booking.date}</p>
                </div>
                <button className="rounded-full border border-border px-4 py-2 text-xs font-bold transition hover:bg-secondary">
                  Book Again
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-muted-foreground">No past bookings yet.</p>
        )}
      </section>

      {/* Saved Tours */}
      <section id="saved-section">
        <h2 className="mb-6 font-serif text-3xl">Saved Tours</h2>
        <div className="grid gap-5 sm:grid-cols-2">
          {savedTours.map((tour) => (
            <div key={tour.id} className="rounded-2xl border border-border bg-card overflow-hidden hover:shadow-lg transition">
              <div className="relative h-40 overflow-hidden">
                <img src={tour.image} alt={tour.title} className="h-full w-full object-cover" />
                <button className="absolute right-3 top-3 rounded-full bg-white p-2 shadow-md transition hover:scale-110">
                  <Heart size={18} className="fill-red-500 text-red-500" />
                </button>
              </div>
              <div className="p-4">
                <h3 className="font-serif text-lg">{tour.title}</h3>
                <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock3 size={14} />
                  <span>{tour.duration}</span>
                </div>
                <p className="mt-3 text-lg font-bold text-primary">AED {tour.price}</p>
                <button className="mt-4 w-full rounded-full border border-primary px-4 py-2 text-xs font-bold text-primary transition hover:bg-primary hover:text-primary-foreground">
                  View Tour
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* My Enquiries */}
      <section id="enquiries-section">
        <h2 className="mb-6 font-serif text-3xl">My Enquiries</h2>
        <div className="space-y-4">
          {enquiries.map((enquiry) => (
            <div key={enquiry.id} className="rounded-2xl border border-border bg-card p-5">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <p className="font-semibold">{enquiry.tourInterest}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{enquiry.date}</p>
                  <p className="mt-2 text-sm text-muted-foreground">{enquiry.message}</p>
                  <span
                    className={`mt-3 inline-block rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${
                      enquiry.status === 'new'
                        ? 'bg-amber-100 text-amber-700'
                        : enquiry.status === 'responded'
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-green-100 text-green-700'
                    }`}
                  >
                    {enquiry.status}
                  </span>
                </div>
                <button className="rounded-lg border border-border p-2 transition hover:bg-secondary">
                  <MessageSquare size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

